import { useRef } from 'react';
import { View, TouchableOpacity, StyleSheet, Text } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';

export default function CameraScreen({
  onPhotoTaken,
  onClose,
}) {
  const cameraRef = useRef(null);

  const [permission, requestPermission] =
    useCameraPermissions();

  const takePicture = async () => {
    if (!cameraRef.current) return;

    const photo =
      await cameraRef.current.takePictureAsync();

    onPhotoTaken(photo.uri);
  };

  if (!permission) {
    return <View />;
  }

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <TouchableOpacity
          style={styles.permissionButton}
          onPress={requestPermission}
        >
          <Text style={{ color: 'white' }}>
            Permitir câmera
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <CameraView
        ref={cameraRef}
        style={{ flex: 1 }}
        facing="back"
      />

      <TouchableOpacity
        style={styles.captureButton}
        onPress={takePicture}
      >
        <Text
          style={{
            color: 'white',
            fontSize: 28,
          }}
        >
          📸
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.closeButton}
        onPress={onClose}
      >
        <Text
          style={{
            color: 'white',
            fontSize: 20,
          }}
        >
          X
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  permissionButton: {
    backgroundColor: '#3E3364',
    padding: 20,
    borderRadius: 10,
  },

  captureButton: {
    position: 'absolute',
    bottom: 50,
    alignSelf: 'center',
    backgroundColor: '#00000099',
    padding: 20,
    borderRadius: 50,
  },

  closeButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    backgroundColor: '#00000099',
    padding: 10,
    borderRadius: 20,
  },
});