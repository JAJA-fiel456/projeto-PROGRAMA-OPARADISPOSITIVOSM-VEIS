import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

export default function TaskItem({ task, deleteTask }) {
  return (
    <View style={styles.container}>
      <View style={styles.taskContainer}>

        {task.image && (
          <Image
            source={{ uri: task.image }}
            style={styles.productImage}
          />
        )}

        <View style={styles.taskInfo}>
          <Text style={styles.title}>
            {task.title}
          </Text>

          <Text style={styles.quantity}>
            Quantidade: {task.quantity}
          </Text>

          {task.description ? (
            <Text style={styles.description}>
              {task.description}
            </Text>
          ) : null}

          {task.price > 0 && (
            <Text style={styles.price}>
              R$ {task.price.toFixed(2)}
            </Text>
          )}

          {task.phone ? (
            <Text style={styles.phone}>
              📞 {task.phone}
            </Text>
          ) : null}
        </View>

        <TouchableOpacity
          style={styles.delete}
          onPress={deleteTask}
        >
          <MaterialIcons
            name="delete"
            size={24}
            color="#FF5252"
          />
        </TouchableOpacity>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 15,
    marginVertical: 6,
  },

  taskContainer: {
    backgroundColor: '#3E3364',
    borderRadius: 12,
    padding: 15,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },

  productImage: {
    width: 70,
    height: 70,
    borderRadius: 10,
    marginRight: 12,
  },

  taskInfo: {
    flex: 1,
  },

  title: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '600',
  },

  quantity: {
    color: '#B0B0FF',
    fontSize: 15,
    marginTop: 4,
  },

  description: {
    color: '#CCCCFF',
    fontSize: 14,
    marginTop: 6,
  },

  price: {
    color: '#4CAF50',
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 6,
  },

  phone: {
    color: '#64B5F6',
    fontSize: 14,
    marginTop: 6,
  },

  delete: {
    marginLeft: 12,
    padding: 5,
  },
});