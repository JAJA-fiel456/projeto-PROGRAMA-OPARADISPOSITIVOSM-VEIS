import { ScrollView } from 'react-native';
import CameraScreen from './CameraScreen';
import { Image } from 'react-native';
import React, { useState } from 'react';
import {
  Platform,
  KeyboardAvoidingView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Text,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

export default function TaskInputField({ addTask }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [phone, setPhone] = useState('');
  const [image, setImage] = useState(null);
  const [showCamera, setShowCamera] = useState(false);
  
  const handleAddTask = () => {
    if (!title.trim()) return;

    addTask({
  title: title.trim(),
  description: description.trim(),
  price: price,
  quantity: quantity,
  phone: phone.trim(),
  image: image,
});

    setTitle('');
    setDescription('');
    setPrice('');
    setQuantity('1');
    setPhone('');
    setImage(null);
  };

  if (showCamera) {
  return (
    <CameraScreen
      onPhotoTaken={(uri) => {
        setImage(uri);
        setShowCamera(false);
      }}
      onClose={() => setShowCamera(false)}
    />
  );
}
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView style={styles.form} showsVerticalScrollIndicator={true}>
        {/* Título */}
        <TextInput
          style={styles.input}
          value={title}
          onChangeText={setTitle}
          placeholder="Nome do item (ex: Arroz)"
          placeholderTextColor={'#bbb'}
        />

        {/* Descrição */}
        <TextInput
          style={[styles.input, { height: 40 }]}
          value={description}
          onChangeText={setDescription}
          placeholder="Descrição (opcional)"
          placeholderTextColor={'#bbb'}
        />

        {/* Preço e Quantidade na mesma linha */}
        <View style={styles.row}>
          <View style={styles.priceContainer}>
            <Text style={styles.currency}>R$</Text>
            <TextInput
              style={styles.priceInput}
              value={price}
              onChangeText={setPrice}
              placeholder="0.00"
              keyboardType="numeric"
              placeholderTextColor={'#bbb'}
            />
          </View>

          <TextInput
            style={[styles.input, styles.quantityInput]}
            value={quantity}
            onChangeText={setQuantity}
            placeholder="Qtd"
            keyboardType="numeric"
            placeholderTextColor={'#bbb'}
          />
        </View>

        {image && (
  <Image
    source={{ uri: image }}
    style={styles.preview}
  />
)}
        <TextInput
          style={styles.input}
          value={phone}
          onChangeText={setPhone}
          placeholder="Telefone (opcional)"
          keyboardType="phone-pad"
          placeholderTextColor={'#bbb'}
        />
      </ScrollView>

      <TouchableOpacity
  style={styles.cameraButton}
  onPress={() => setShowCamera(true)}
>
  <MaterialIcons
    name="photo-camera"
    size={24}
    color="white"
  />
</TouchableOpacity>
      <TouchableOpacity onPress={handleAddTask} style={styles.buttonContainer}>
        <View style={styles.button}>
          <MaterialIcons name="add" size={28} color="#1E1A3C" />
        </View>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#3E3364',
    borderTopWidth: 1,
    borderColor: '#555',
    paddingHorizontal: 15,
    paddingVertical: 10,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxHeight: 220,        // Muito mais compacto
  },
  form: {
    gap: 6,
  },
  input: {
    color: '#fff',
    backgroundColor: '#2C2545',
    borderRadius: 8,
    padding: 10,
    fontSize: 15,
  },
  row: {
    flexDirection: 'row',
    gap: 8,
  },
  priceContainer: {
    flex: 1.3,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2C2545',
    borderRadius: 8,
    paddingHorizontal: 10,
  },
  currency: {
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  priceInput: {
    color: '#fff',
    flex: 1,
    padding: 10,
    fontSize: 15,
  },
  quantityInput: {
    flex: 0.7,
  },
  buttonContainer: {
    alignSelf: 'flex-end',
    marginTop: 8,
  },
 button: {
  height: 42,
  width: 42,
  borderRadius: 21,
  backgroundColor: '#fff',
  alignItems: 'center',
  justifyContent: 'center',
},

cameraButton: {
  width: 42,
  height: 42,
  borderRadius: 21,
  backgroundColor: '#5C4D91',
  justifyContent: 'center',
  alignItems: 'center',
  alignSelf: 'flex-end',
  marginBottom: 8,
},

preview: {
  width: 80,
  height: 80,
  borderRadius: 10,
  alignSelf: 'center',
  marginBottom: 10,
},
  },
);