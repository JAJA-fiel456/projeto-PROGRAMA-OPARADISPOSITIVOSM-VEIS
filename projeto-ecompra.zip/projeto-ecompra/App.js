import { Keyboard, ScrollView, Text, View, StyleSheet } from 'react-native';
import { useState, useEffect, useRef } from 'react';
import TaskInputField from './components/TaskInputField';
import TaskItem from './components/TaskItem';
import * as SQLite from 'expo-sqlite';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Usamos ref para manter a conexão do banco
  const dbRef = useRef(null);

  const getDB = async () => {
    if (!dbRef.current) {
      dbRef.current = await SQLite.openDatabaseAsync('ecompra.db');
    }
    return dbRef.current;
  };

  useEffect(() => {
    initializeDatabase();
  }, []);

  const initializeDatabase = async () => {
    try {
      const db = await getDB();

      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS products (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          description TEXT,
          price REAL,
          phone TEXT,
          quantity INTEGER,
          image TEXT
        );
      `);

      await loadTasks();
    } catch (error) {
      console.error('Erro ao criar banco:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadTasks = async () => {
    try {
      const db = await getDB();
      const result = await db.getAllAsync(
        'SELECT * FROM products ORDER BY id DESC'
      );
      setTasks(result);
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
    }
  };

  const addTask = async (newTask) => {
    if (!newTask?.title?.trim()) return;

    try {
      const db = await getDB();
      await db.runAsync(
        `INSERT INTO products 
         (title, description, price, phone, quantity, image)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          newTask.title,
          newTask.description || '',
          parseFloat(newTask.price) || 0,
          newTask.phone || '',
          parseInt(newTask.quantity) || 1,
          newTask.image || null,
        ]
      );

      await loadTasks();
      Keyboard.dismiss();
    } catch (error) {
      console.error('Erro ao salvar produto:', error);
    }
  };

  const deleteTask = async (id) => {
    try {
      const db = await getDB();
      await db.runAsync('DELETE FROM products WHERE id = ?', [id]);
      await loadTasks();
    } catch (error) {
      console.error('Erro ao excluir produto:', error);
    }
  };

  if (isLoading) {
    return (
      <View style={styles.container}>
        <Text style={styles.heading}>🛒 eCompra</Text>
        <Text style={{ color: '#FFF', textAlign: 'center', marginTop: 50 }}>
          Carregando...
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>🛒 eCompra</Text>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={true}
        keyboardShouldPersistTaps="handled"
      >
        {tasks.map((task) => (
          <TaskItem
            key={task.id}
            task={task}
            deleteTask={() => deleteTask(task.id)}
          />
        ))}

        {tasks.length === 0 && (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              Nenhum produto adicionado ainda
            </Text>
          </View>
        )}
      </ScrollView>

      <TaskInputField addTask={addTask} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1E1A3C',
  },

  heading: {
    color: '#FFF',
    fontSize: 26,
    fontWeight: 'bold',
    marginTop: 50,
    marginBottom: 15,
    marginLeft: 20,
  },

  scrollView: {
    flex: 1,
  },

  scrollContent: {
    paddingBottom: 180,
    paddingHorizontal: 10,
  },

  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 100,
  },

  emptyText: {
    color: '#888',
    fontSize: 16,
  },
});